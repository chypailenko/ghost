/*Libs include*/
//= ../libs/jquery/dist/jquery.js

/*Modules include*/
//= ./common/localStorage.js

console.log(2323);